#!/bin/bash

mkdir _build
cmake -B _build
cd _build
make
