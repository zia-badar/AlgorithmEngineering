#!/bin/bash

cmake .
make
