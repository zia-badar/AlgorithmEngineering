running "compile.sh" compiles the program
running "benchmark-wce.sh" script in "wce-students" directory starts testing the program
*data sets need to copied into "wce-students" directory for "benchmark-wce.sh" script to work
